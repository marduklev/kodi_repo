# skin.swan-alpha
<img src='./resources/fanart.jpg'>

## Features
>
>      4 Home Layouts ( Widgets Only , Netflix Style, * , * ) + unique settings depending on layout
>      Custom Widget Configuration 
>			 - set path (native)
>            - limit, Sortortder, Sortby, Layouts[8 + ? ] ( native + 'script.EmbuaryHelper' for post-define have Select Dialog )
>            Use Custom Background Images (+ tint image or use tinted overlay, as layer2)
>            Use Custom Background Overlay Image + use Custom Color Tint ( as layer3 )
>            Use Custom Colors ( 'script.skinhelper.colorpicker' or native colorthemes)
>            - choose predefinded themes
>            - change the whole colors to fit it your likings
>      2 VideoInfo Layouts
>      2 OSD Layouts
>      
>      Embuary TmDB VideoInfo Helper support
>      Special Ratings for Library/Views (show tmbd,tvdb,imdb,rottentomatoes,metacritic)
>      StudioLogo Resource Addon Support (colored, monochrome)
		
### Dependencies
>	(Embuary Helper)[https://forum.kodi.tv/showthread.php?tid=345471]
### Supported Addons
>	(Embuary Info Script)[https://forum.kodi.tv/showthread.php?tid=346034]
>   (Up Next)[https://forum.kodi.tv/showthread.php?tid=336747]
>	Resource Addon For Actor Thumbs (used in ... ) (resource.images.moviedirectorthumbs) https://forum.kodi.tv/showthread.php?tid=342720

## Credits for (some defaults) currently used Textures belongs to
- @'Phil65' (skin.estuary) (default[foo].pngs's, some backgroundpatterns)
- @'Marcelveldt' , @'mgonzales71' (resource.images.backgroundoverlays.basic)
- some icons taken from https://materialdesignicons.com/

