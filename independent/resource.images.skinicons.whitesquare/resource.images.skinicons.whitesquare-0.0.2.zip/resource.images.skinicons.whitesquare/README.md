# resource.images.skinicons.whitesquare
# source of images are skinicons.wide by marcelveldt
