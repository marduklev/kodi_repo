
### Release 0.0.2 (061618) ###
* Features Request Additions:
  * Added Property "TVMelodies.isPlaying".
  * Added Option for delay up to 10 seconds.
* Bug Fixes:
  * Themes now stop playing when changing to another item.

### Release 0.0.1 (061618) ###
* Initialize script on Github
