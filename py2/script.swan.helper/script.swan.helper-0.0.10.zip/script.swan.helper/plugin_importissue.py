# -*- coding: utf-8 -*-
# - test use class n import lib

from resources.lib.plugincontent import PluginContent

if __name__ == "__main__":
    PluginContent()
