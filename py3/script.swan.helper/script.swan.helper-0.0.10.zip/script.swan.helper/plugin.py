# -*- coding: utf-8 -*-
# - test use class n import lib

from resources.lib.plugin_content import PluginContent

if __name__ == "__main__":
    PluginContent()
