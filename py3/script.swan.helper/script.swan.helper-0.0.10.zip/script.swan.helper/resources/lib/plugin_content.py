# -*- coding: utf-8 -*-
# info - https://romanvm.github.io/Kodistubs/_autosummary/xbmcplugin.html

from resources.lib.utils import log

import xbmc
import xbmcplugin
import xbmcgui

import sys
import urllib.parse
import json


class PluginContent:
    params = {}
    
    def __init__(self):
        self.params = dict(urllib.parse.parse_qsl(sys.argv[2].replace('?', '').lower()))
        self.main()

    def main(self):
        action = self.params.get("action")
        
        try:
            getattr(self, action)()
        except:
            log(f'PLUGIN EXCEPTION : locals = [{locals()}')
    
    def get_cast(self):
        dbtype = self.params["dbtype"]
        dbid = self.params["dbid"]
        
        if dbtype == "set":
            result = xbmc.executeJSONRPC(' {"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieSetDetails", "params": {"setid": %s}, "id": 1} ' % (dbid))
            movies_from_set = json.loads(result)["result"]["setdetails"]["movies"]
            
            movie_id_list = []
            for index in range(len(movies_from_set)):
                movie_id_list.append(movies_from_set[index]["movieid"])
            
            cast_list = []
            for index in range(0,len(movies_from_set)-1):
                dbid = movie_id_list[index]
                result = xbmc.executeJSONRPC(' {"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {"movieid": %s, "properties": ["cast"]}, "id": 1} ' % dbid)
                cast_l_cache = json.loads(result)["result"]["moviedetails"]["cast"][:5]
                cast_list.extend(cast_l_cache)
            
            cast_l_cache = []
            for cast_member in cast_list:
                if cast_member not in cast_l_cache:
                    cast_l_cache.append(cast_member)
            cast_list = cast_l_cache
        
        else:
            result = xbmc.executeJSONRPC(' {"jsonrpc": "2.0", "method": "VideoLibrary.Get%sDetails", "params": {"%sid": %s, "properties": ["cast"]}, "id": 1} ' % (dbtype,dbtype,dbid))
            
            if dbtype == "tvshow":
                cast_list = json.loads(result)["result"]["tvshowdetails"]["cast"]
            elif dbtype == "movie":
                cast_list = json.loads(result)["result"]["moviedetails"]["cast"]
            elif dbtype == "episode":
                cast_list = json.loads(result)["result"]["episodedetails"]["cast"]
        
        log(f'{locals()}\n   cast_list {cast_list}')        
        # process listing with the results ,  maybe need look here too https://github.com/xbmc/xbmc/pull/19459#issuecomment-806450382
        for actor in cast_list:
            list_item = xbmcgui.ListItem(label=actor.get("name"), label2=actor.get("role"), offscreen=True)
            
            '''
                    param label                [opt] string (default `""`) - the label to display on the item
                    param label2               [opt] string (default `""`) - the label2 of the item
                    param path                 [opt] string (default `""`) - the path for the item
                    param offscreen            [opt] bool (default `False`) - if GUI based locks should be
                                             avoided. Most of the times listitems are created
                                             offscreen and added later to a container
                                             for display (e.g. plugins) or they are not
                                             even displayed (e.g. python scrapers).
                                             In such cases, there is no need to lock the
                                             GUI when creating the items (increasing your addon
                                             performance).
                                             Note however, that if you are creating listitems
                                             and managing the container itself (e.g using
                                             WindowXML or WindowXMLDialog classes) subsquent
                                             modifications to the item will require locking.
                                             Thus, in such cases, use the default value (`False`).
             '''
            list_item.setArt({"thumb":actor.get("thumbnail")})
            # # 20 Partially deprecated. Use explicit setters in **InfoTagVideo**, **InfoTagMusic**, **InfoTagPicture** or **InfoTagGame** instead.
            # listitem.setInfo('video', { 'genre': 'Comedy' })
            # # >20 ? 
            # listitem.addAvailableArtwork(actor.get("thumbnail"), "thumb")
            '''
                InfoTagVideo.addAvailableArtwork()
                    void addAvailableArtwork(const std::string& url,
                               const std::string& art_type = "",
                               const std::string& preview = "",
                               const std::string& referrer = "",
                               const std::string& cache = "",
                               bool post = false,
                               bool isgz = false,
                               int season = -1);
            '''
            
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=list_item, isFolder=False, totalItems=0)
                
        # finish it
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    # def get_traileritem(self):
        # no hidden button needed then ?
        # interesting
    
    
    def get_alphabetbar(self):
        # only todo is refreshing - sortorder change via gui or other plugin://script.swan.helper/?action=get_alphabetbar;reload=$INFO[Container.NumItems], in generell its sorted by label
        if xbmc.getInfoLabel('container.numitems'):
            all_letters = []
            letter_item_dict ={}
            # total_items = int(xbmc.getInfoLabel('container.numitems'))
            
            for i in range(int(xbmc.getInfoLabel('container.numitems'))):
                all_letters.append(xbmc.getInfoLabel("ListItemAbsolute(%s).SortLetter" % i).upper())
                letter_item = all_letters[i]
                if letter_item not in letter_item_dict:
                    letter_item_dict[f'{all_letters[i]}'] = i
            
            # log(f' final_dict: {letter_item_dict}, type final_dict_keys : {letter_item_dict.keys()}')
            
            for key_item in list(letter_item_dict):
                listitem = xbmcgui.ListItem(label=key_item)
                offset = letter_item_dict[f"{key_item}"]
                log(f'key_item is {key_item}')
                lipath = f"plugin://script.swan.helper/?action=jumpabsolute&id={offset}"
                xbmcplugin.addDirectoryItem(int(sys.argv[1]), lipath, listitem, isFolder=False)
        
        # calling
        log(f'am i here before i clicked {letter_item_dict[f"{key_item}"]} | offset = {offset} | sys={int(sys.argv[1])}')
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
        
    def jumpabsolute(self):
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=False, listitem=xbmcgui.ListItem())
        
        absolutepos = self.params.get("id")
        # didnt found any good way to get view id, than set label in skin, except xbmc.sleep
        fake_view_id = xbmc.getInfoLabel('window.property(viewid)')
        
        xbmc.executebuiltin(f'SetFocus({fake_view_id},{absolutepos},absolute)')
