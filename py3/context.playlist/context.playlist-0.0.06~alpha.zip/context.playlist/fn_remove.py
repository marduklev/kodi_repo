# -*- coding: utf-8 -*-
import xbmc

def main():
    playlistid = 1 if xbmc.getCondVisibility('player.hasvideo') else 0
    playlist = xbmc.PlayList(playlistid)
    filename = xbmc.getInfoLabel('listitem.filename')
    playlist.remove(filename)

if __name__ == '__main__':
    main()
