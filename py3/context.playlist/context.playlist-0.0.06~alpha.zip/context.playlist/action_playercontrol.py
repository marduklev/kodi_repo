# -*- coding: utf-8 -*-
import xbmc

def main():
    xbmc.executebuiltin('activatewindow(playercontrols)')

if __name__ == '__main__':
    main()
