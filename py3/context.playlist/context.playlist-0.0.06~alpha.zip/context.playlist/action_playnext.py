# -*- coding: utf-8 -*-
import xbmc

def main():
    xbmc.Player().playnext()

if __name__ == '__main__':
    main()
