# -*- coding: utf-8 -*-
import xbmc

def main():
    xbmc.executebuiltin('action(playlist)')

if __name__ == '__main__':
    main()
