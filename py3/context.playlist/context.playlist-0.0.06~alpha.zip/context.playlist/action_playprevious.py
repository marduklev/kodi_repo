# -*- coding: utf-8 -*-
import xbmc

def main():
    xbmc.Player().playprevious()

if __name__ == '__main__':
    main()
